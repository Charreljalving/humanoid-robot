import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Blog } from './components/Blog';
import { Interactive } from './components/Interactive';
import { GlobalImpact } from './components/GlobalImpact';
import { Footer } from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white text-neutral-900">
      <Header />
      <Hero />
      <Blog />
      <Interactive />
      <GlobalImpact />
      <Footer />
    </div>
  );
}

export default App;