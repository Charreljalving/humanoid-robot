import React, { useState } from 'react';
import { CircuitBoard, Menu, X } from 'lucide-react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed w-full bg-black/20 backdrop-blur-sm z-50">
      <nav className="container mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <CircuitBoard className="w-8 h-8 text-white" />
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full" />
          </div>
          <span className="text-xl font-bold text-white">
            RoboTracker
          </span>
        </div>

        <div className="hidden md:flex space-x-8">
          <a href="#latest" className="text-white/80 hover:text-white transition">Blog</a>
          <a href="#interactive" className="text-white/80 hover:text-white transition">Interactief</a>
          <a href="#impact" className="text-white/80 hover:text-white transition">Impact</a>
        </div>

        <button className="hidden md:block bg-white text-neutral-900 hover:bg-white/90 px-6 py-2 rounded-md transition">
          Abonneren
        </button>

        <button 
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? (
            <X className="w-6 h-6 text-white" />
          ) : (
            <Menu className="w-6 h-6 text-white" />
          )}
        </button>
      </nav>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-black/90 border-t border-white/10">
          <div className="container mx-auto px-6 py-4 space-y-4">
            <a href="#latest" className="block text-white/80 hover:text-white">Blog</a>
            <a href="#interactive" className="block text-white/80 hover:text-white">Interactief</a>
            <a href="#impact" className="block text-white/80 hover:text-white">Impact</a>
            <div className="pt-4 border-t border-white/10">
              <button className="w-full bg-white text-neutral-900 hover:bg-white/90 px-6 py-2 rounded-md">
                Abonneren
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}