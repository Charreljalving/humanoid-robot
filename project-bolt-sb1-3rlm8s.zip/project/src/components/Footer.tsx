import React from 'react';
import { Bot, Github, Twitter, Linkedin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-neutral-900 py-12 px-6">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="flex items-center space-x-2 mb-4 md:mb-0">
            <Bot className="w-8 h-8 text-white" />
            <span className="text-xl font-bold text-white">RoboTracker</span>
          </div>
          <div className="flex space-x-6">
            <Github className="w-6 h-6 text-white hover:text-neutral-300 cursor-pointer transition" />
            <Twitter className="w-6 h-6 text-white hover:text-neutral-300 cursor-pointer transition" />
            <Linkedin className="w-6 h-6 text-white hover:text-neutral-300 cursor-pointer transition" />
          </div>
        </div>
        <div className="border-t border-neutral-800 pt-8">
          <p className="text-center text-neutral-400">
            © 2024 RoboTracker. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}